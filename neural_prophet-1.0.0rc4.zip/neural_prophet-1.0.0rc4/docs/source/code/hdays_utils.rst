Core Module Documentation
==========================

.. automodule:: neuralprophet.hdays_utils
   :members: