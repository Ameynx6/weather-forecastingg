# Contribute

We compiled a [Contributing to NeuralProphet](https://github.com/ourownstory/neural_prophet/blob/master/CONTRIBUTING.md) page with practical instructions and further resources to help you become part of the family. 