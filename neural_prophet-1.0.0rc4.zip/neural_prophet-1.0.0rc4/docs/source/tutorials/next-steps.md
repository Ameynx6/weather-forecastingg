# Next steps

1. Browse the [feature guides and application examples](../how-to-guides/index.rst)
2. Read about the [science behind](../science-behind/model-overview.md) NeuralProphet
3. Explore the [source code](https://github.com/ourownstory/neural_prophet) and [API reference](../code/forecaster.rst) of NeuralProphet
4. Join the community on [Github](https://github.com/ourownstory/neural_prophet) or [Slack](https://join.slack.com/t/neuralprophet/shared_invite/zt-1iyfs2pld-vtnegAX4CtYg~6E~V8miXw)
