Welcome to our documentation!
In the source folder, you can find the quickstart tutorial  and further [basic tutorials](/docs/source/tutorials/index.rst) to get you started with NeuralProphet.
The [how-to-guides](/docs/source/how-to-guides/index.rst) folder contains more advanced notebooks for the different features of NeuralProphet and application examples. Feel free to explore!