$(function () {
    // init feather icons
    feather.replace();
});